import pkg_resources

__version__ = pkg_resources.require("ckanapi")[0].version


